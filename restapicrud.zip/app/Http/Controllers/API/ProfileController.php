<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Profile;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function index()
    {
        $profiles = Profile::all();

        return response()->json([
            'success' => true,
            'message' => 'Profiles retrieved successfully',
            'data' => $profiles
        ]);
    }

    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'school_name' => 'required|string',
            'school_location' => 'required|string',
            'school_class' => 'required|string',
            'address' => 'required|string',
            'about' => 'nullable|string',
        ]);
        
        $profile = new Profile();
        $profile->fill($request->all());
        $profile->user_id = Auth::id();
        $profile->save();

        return response()->json([
            'success' => true,
            'message' => 'Profile created successfully',
            'data' => $profile
        ]);
    }

    public function show($id)
    {
        $profile = Profile::find($id);

        if (!$profile) {
            return response()->json([
                'success' => false,
                'message' => 'Profile not found',
                'data' => null
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Profile retrieved successfully',
            'data' => $profile
        ]);
    }

    public function update(Request $request, $id)
    {
        // Validasi input
        $request->validate([
            'school_name' => 'required|string',
            'school_location' => 'required|string',
            'school_class' => 'required|string',
            'address' => 'required|string',
            'about' => 'nullable|string',
        ]);

        $profile = Profile::find($id);

        if (!$profile) {
            return response()->json([
                'success' => false,
                'message' => 'Profile not found',
                'data' => null
            ], 404);
        }

        $profile->fill($request->all());
        $profile->save();

        return response()->json([
            'success' => true,
            'message' => 'Profile updated successfully',
            'data' => $profile
        ]);
    }

    public function destroy($id)
    {
        $profile = Profile::find($id);

        if (!$profile) {
            return response()->json([
                'success' => false,
                'message' => 'Profile not found',
                'data' => null
            ], 404);
        }

        $profile->delete();

        return response()->json([
            'success' => true,
            'message' => 'Profile deleted successfully'
        ]);
    }
}
